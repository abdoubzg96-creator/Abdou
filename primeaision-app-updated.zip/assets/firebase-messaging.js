/*
 * Real push notifications (Firebase Cloud Messaging) for the web app.
 *
 * Setup required before this works (one-time, in Firebase Console):
 *   1. Project settings -> Cloud Messaging -> "Web configuration" ->
 *      generate a "Web Push certificate" (VAPID key).
 *   2. Paste that key into assets/firebase-config.js:
 *        window.PRIMEAISION_FIREBASE_CONFIG.vapidKey = "PASTE_KEY_HERE";
 *   3. Deploy over HTTPS (required by the browser Push API — localhost
 *      also works for testing, file:// does not).
 *
 * To actually SEND a notification to a signed-in person from your own
 * backend/cron job, call the FCM HTTP v1 API with the token that gets
 * saved to your Realtime Database at notificationTokens/{uid}.
 *
 * If this site is later wrapped with Capacitor for Android (see
 * README-ANDROID.md), the native @capacitor/push-notifications plugin
 * takes over automatically on native builds, and this file quietly
 * does nothing there (see the Capacitor check below) so tokens aren't
 * registered twice.
 */
(function () {
  const config = window.PRIMEAISION_FIREBASE_CONFIG || {};
  const configured = config.apiKey && !String(config.apiKey).includes("YOUR_");
  const isNativeApp = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  const copy = {
    enable: "تفعيل الإشعارات",
    enabled: "الإشعارات مفعّلة",
    blocked: "الإشعارات محظورة من إعدادات المتصفح.",
    error: "تعذّر تفعيل الإشعارات الآن.",
    noVapid: "أضف vapidKey في assets/firebase-config.js أولاً.",
  };

  function injectStyles() {
    const style = document.createElement("style");
    style.textContent = `
      #prime-notif-toast {
        position: fixed;
        inset: auto 1rem 5rem auto;
        z-index: 1500;
        max-width: 320px;
        background: #172033;
        color: #fff;
        border-radius: .85rem;
        padding: .85rem 1rem;
        font: 600 .85rem/1.5 Inter, system-ui, sans-serif;
        box-shadow: 0 16px 40px rgba(15,23,42,.35);
      }
    `;
    document.head.appendChild(style);
  }

  function showToast(title, body) {
    const toast = document.createElement("div");
    toast.id = "prime-notif-toast";
    toast.innerHTML = `<strong>${title || "PrimeAIsion"}</strong><div style="font-weight:400;margin-top:.25rem">${body || ""}</div>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 6000);
  }

  async function saveToken(token) {
    if (!config.databaseURL) return;
    const uid = (window.PrimeAIsionAuth && window.PrimeAIsionAuth.getCurrentUser() && window.PrimeAIsionAuth.getCurrentUser().uid)
      || localStorage.getItem("primeaision-anon-id")
      || (() => {
        const id = "anon-" + Math.random().toString(36).slice(2);
        localStorage.setItem("primeaision-anon-id", id);
        return id;
      })();
    try {
      await fetch(`${config.databaseURL}/notificationTokens/${uid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, updatedAt: Date.now(), platform: "web" }),
      });
    } catch (error) {
      console.warn("PrimeAIsion: could not save notification token", error);
    }
  }

  // Returns { ok: true } on success, or { ok: false, reason, message }
  // so the caller (the toggle in Settings) can show its own UI state
  // instead of this file popping up alerts on top of a settings screen.
  async function enableNotifications() {
    if (!("Notification" in window) || !("serviceWorker" in navigator)) {
      return { ok: false, reason: "unsupported", message: copy.error };
    }
    if (!config.vapidKey) {
      return { ok: false, reason: "no-vapid", message: copy.noVapid };
    }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      return { ok: false, reason: "blocked", message: copy.blocked };
    }
    try {
      const { initializeApp, getApps } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js");
      const { getMessaging, getToken, onMessage } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-messaging.js");

      const app = getApps().length ? getApps()[0] : initializeApp(config);
      const registration = await navigator.serviceWorker.register("/firebase-messaging-sw.js");
      const messaging = getMessaging(app);
      const token = await getToken(messaging, {
        vapidKey: config.vapidKey,
        serviceWorkerRegistration: registration,
      });
      if (!token) {
        return { ok: false, reason: "no-token", message: copy.error };
      }
      await saveToken(token);
      localStorage.setItem("primeaision-notifications-enabled", "1");
      onMessage(messaging, (payload) => {
        const notification = payload.notification || {};
        showToast(notification.title, notification.body);
      });
      return { ok: true };
    } catch (error) {
      console.error("PrimeAIsion: notification setup failed", error);
      return { ok: false, reason: "error", message: copy.error };
    }
  }

  function init() {
    if (!configured || isNativeApp) return;
    injectStyles();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Public API used by assets/settings-notifications.js to render the
  // toggle inside the settings/profile page instead of a floating button
  // that used to show on every screen.
  window.PrimeAIsionNotifications = {
    isConfigured: () => configured && !isNativeApp,
    isEnabled: () => localStorage.getItem("primeaision-notifications-enabled") === "1",
    enable: enableNotifications,
    copy,
  };
})();
