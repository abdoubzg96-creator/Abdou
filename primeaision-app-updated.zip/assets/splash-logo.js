/*
 * Very first screen: a blue background with just the PrimeAIsion mark,
 * shown for a couple of seconds on every load, then it fades out and
 * whatever should come next (the login/splash screen from
 * assets/splash-login.js, or straight into the app) appears underneath —
 * it has been rendering in the background the whole time, so nothing is
 * delayed by this, it's just visually covered for a moment.
 */
(function () {
  const MIN_VISIBLE_MS = 1800;

  function build() {
    const el = document.createElement("div");
    el.id = "prime-logo-splash";
    el.innerHTML = `
      <div class="prime-logo-mark" aria-hidden="true">P</div>
      <div class="prime-logo-wordmark">PrimeAIsion</div>
    `;
    document.body.appendChild(el);
    return el;
  }

  function init() {
    const el = build();
    setTimeout(() => {
      el.classList.add("prime-logo-hide");
      setTimeout(() => el.remove(), 350);
    }, MIN_VISIBLE_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
