/*
 * Puts the "enable notifications" control inside the app's own Settings
 * page (the "التفضيلات" card on /profile, right under "الوضع الليلي"),
 * instead of a button floating on every screen.
 *
 * The compiled app (assets/index-BIAuf08k.js) is left untouched, so this
 * watches the page for that settings card and appends a matching row to
 * it — same classes as the dark-mode row, so it looks like it was always
 * part of the page. It only ever appears while that settings card is on
 * screen.
 */
(function () {
  const ROW_ID = "prime-notif-settings-row";

  function alreadyInjected(card) {
    return card.querySelector("#" + ROW_ID);
  }

  function buildRow() {
    const api = window.PrimeAIsionNotifications;
    const enabledAlready = !!(api && api.isEnabled());

    const row = document.createElement("div");
    row.id = ROW_ID;
    row.className = "flex items-center justify-between gap-4 border-b border-[hsl(var(--border))] py-4";
    row.innerHTML = `
      <div>
        <strong class="block">الإشعارات</strong>
        <span class="text-sm text-[hsl(var(--muted-foreground))]">تنبيهات بالدروس الجديدة والتذكيرات</span>
      </div>
      <button type="button" data-testid="button-toggle-notifications"
        aria-label="تبديل الإشعارات"
        class="relative h-7 w-12 rounded-full transition ${enabledAlready ? "bg-[hsl(var(--primary))]" : "bg-[hsl(var(--border))]"}">
        <span class="absolute top-1 h-5 w-5 rounded-full bg-white transition ${enabledAlready ? "right-1" : "right-6"}"></span>
      </button>
    `;

    const toggle = row.querySelector("button");
    toggle.disabled = enabledAlready;

    toggle.addEventListener("click", async () => {
      if (!api || !api.isConfigured()) {
        window.alert((api && api.copy && api.copy.noVapid) || "الإشعارات غير مهيأة بعد.");
        return;
      }
      toggle.disabled = true;
      const result = await api.enable();
      if (result.ok) {
        toggle.className = toggle.className.replace("bg-[hsl(var(--border))]", "bg-[hsl(var(--primary))]");
        toggle.querySelector("span").className = toggle.querySelector("span").className.replace("right-6", "right-1");
      } else {
        toggle.disabled = false;
        window.alert(result.message || "تعذّر تفعيل الإشعارات الآن.");
      }
    });

    return row;
  }

  function buildPasswordRow() {
    const row = document.createElement("div");
    row.id = "prime-password-settings-row";
    row.className = "flex items-center justify-between gap-4 border-b border-[hsl(var(--border))] py-4";
    row.innerHTML = `
      <div>
        <strong class="block">كلمة المرور</strong>
        <span class="text-sm text-[hsl(var(--muted-foreground))]">نرسل لك رابط تغيير كلمة المرور على بريدك</span>
      </div>
      <button type="button" data-testid="button-change-password" class="secondary-button">تغيير</button>
    `;

    const button = row.querySelector("button");
    button.addEventListener("click", async () => {
      const auth = window.PrimeAIsionAuth;
      if (!auth || !auth.getCurrentUser()) {
        window.alert("لازم تسجّل الدخول أولاً باش تغيّر كلمة المرور.");
        return;
      }
      button.disabled = true;
      const result = await auth.changePassword();
      button.disabled = false;
      if (result.ok) {
        window.alert(`تبعثلك رسالة على ${result.email} فيها رابط تغيير كلمة المرور.`);
      } else if (result.reason === "signed-out") {
        window.alert("لازم تسجّل الدخول أولاً باش تغيّر كلمة المرور.");
      } else {
        window.alert(result.message || "تعذّر إرسال رابط تغيير كلمة المرور الآن.");
      }
    });

    return row;
  }

  function tryInject() {
    const darkModeToggle = document.querySelector('[data-testid="button-toggle-dark-mode"]');
    if (!darkModeToggle) return;
    const card = darkModeToggle.closest(".content-card");
    if (!card || alreadyInjected(card)) return;
    const darkModeRow = darkModeToggle.closest("div.flex.items-center.justify-between");
    const notifRow = buildRow();
    const passwordRow = buildPasswordRow();
    if (darkModeRow && darkModeRow.parentElement === card) {
      darkModeRow.insertAdjacentElement("afterend", notifRow);
      notifRow.insertAdjacentElement("afterend", passwordRow);
    } else {
      card.appendChild(notifRow);
      card.appendChild(passwordRow);
    }
  }

  function init() {
    tryInject();
    const observer = new MutationObserver(tryInject);
    observer.observe(document.getElementById("root") || document.body, {
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
